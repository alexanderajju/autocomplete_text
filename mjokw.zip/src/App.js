import React, { useState, useEffect } from "react";
import { ReactSearchAutocomplete } from "react-search-autocomplete";

function App() {

// useState is react hook used for storing data
  const [fruit, setFruits] = useState([
    {
      id: 0,
      name: "Apple"
    },
    {
      id: 1,
      name: "Orange"
    },
    {
      id: 2,
      name: "Banana"
    }
  ]);
// A sample of fruits are used for this is given below, 
  // https://postmanmaster.herokuapp.com/fruit/

// Use effect is used to call the api when the page loads
  useEffect(() => {
    // In order to wait for any delay or promise
    const getFruits = async () => {
      await fetch("https://postmanmaster.herokuapp.com/fruit/")
        .then((response) => response.json())
        .then((data) => {
//  Depending upon the data received from the api code chages 
          setFruits(data);
          // Console.log is used to print the result in the console of the browser
          // data.map((a) => console.log([{ id: a.id, name: a.name }]));
        });
    };

    getFruits();
    // console.log("fruits>>>>>>>>>>", fruit);
  }, []);


// Intializing the functions of ReactSearchAutocomplete
  
const handleOnSearch = (string, results) => {
    // console.log(string, results);
  };

const handleOnHover = (result) => {
    // console.log(result);
  };

const handleOnSelect = (item) => {
    // console.log(item);
    alert(item.name);
  };

const handleOnFocus = () => {
    // console.log("Focused");
  };

const handleOnClear = () => {
    // console.log("Cleared");
  };

  return (
    <div className="App">
      <header className="App-header">
        <div style={{ width: 200, margin: 20 }}>
          <ReactSearchAutocomplete
            items={fruit}
            onSearch={handleOnSearch}
            onHover={handleOnHover}
            onSelect={handleOnSelect}
            onFocus={handleOnFocus}
            onClear={handleOnClear}
            autoFocus
          />
        </div>
      </header>
    </div>
  );
}

export default App;
